std::vector<LWGEOM *> lwgeom_from_sfc(Rcpp::List sfc);
Rcpp::List sfc_from_lwgeom(std::vector<LWGEOM *> lwgeom_v);
