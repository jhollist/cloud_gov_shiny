library(testthat)
library(ncmeta)

test_check("ncmeta")
