library(testthat)
library(DBI)
library(pool)

test_check("pool")
